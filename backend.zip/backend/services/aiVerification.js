const OpenAI = require("openai");

const client = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
});


async function verifyProof({
    imageUrl,
    challenge,
    commitment
}) {

    const response = await client.responses.create({

        model: "gpt-4.1-mini",

        input: [
            {
                role: "user",

                content: [
                    {
                        type: "input_text",

                        text: `
You are verifying proof for a daily accountability
commitment.

Commitment:
${commitment.name}

Description:
${commitment.description}

Today's challenge:
${challenge}

Analyze the uploaded image and determine whether
it appears to provide reasonable visual evidence
that the user completed today's challenge.

Do NOT identify the person in the image.

Return ONLY valid JSON in this format:

{
  "verified": true,
  "confidence": 0,
  "reason": "short explanation"
}

Rules:

- verified should be true only when the image reasonably
  supports the challenge.
- verified should be false when the image is unrelated,
  unclear, or provides insufficient evidence.
- confidence must be a number from 0 to 100.
- Keep reason short.
`
                    },

                    {
                        type: "input_image",
                        image_url: imageUrl
                    }
                ]
            }
        ]
    });


    const text = response.output_text;


    try {

        return JSON.parse(text);

    } catch {

        return {
            verified: false,
            confidence: 0,
            reason:
                "AI returned an invalid verification response."
        };

    }
}


module.exports = {
    verifyProof
};