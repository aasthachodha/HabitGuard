const express = require("express");
const multer = require("multer");
const ImageKit = require("@imagekit/nodejs");

const DailyProgress = require("../models/DailyProgress");
const DailyChallenge = require("../models/DailyChallenge");
const Commitment = require("../models/Commitment");

const authMiddleware = require("../middleware/authMiddleware");

const { verifyProof } = require("../services/aiVerification");

const router = express.Router();

router.use(authMiddleware);


// =========================
// MULTER
// =========================

const upload = multer({

    storage: multer.memoryStorage(),

    limits: {
        fileSize: 10 * 1024 * 1024
    },

    fileFilter: (req, file, cb) => {

        if (file.mimetype.startsWith("image/")) {
            cb(null, true);
        } else {
            cb(new Error("Only image files are allowed."));
        }

    }

});


// =========================
// IMAGEKIT
// =========================

const imagekit = new ImageKit({

    privateKey:
        process.env.IMAGEKIT_PRIVATE_KEY

});


// =========================
// START OF DAY
// =========================

function startOfDay(date = new Date()) {

    const value = new Date(date);

    value.setHours(0, 0, 0, 0);

    return value;

}


// =========================
// UPLOAD TODAY'S PROOF
// =========================

router.post(
    "/upload",
    upload.single("proof"),
    async (req, res) => {

        try {

            if (!req.file) {
                return res.status(400).json({
                    message: "Please select an image."
                });
            }

            const { commitmentId } = req.body;

            if (!commitmentId) {
                return res.status(400).json({
                    message: "Commitment ID is required."
                });
            }

            // Check commitment belongs to logged-in user
            const commitment = await Commitment.findOne({
                _id: commitmentId,
                userId: req.user.id
            });

            if (!commitment) {
                return res.status(404).json({
                    message: "Commitment not found."
                });
            }

            // Upload image to ImageKit
            const result = await imagekit.files.upload({

                file: req.file.buffer.toString("base64"),

                fileName:
                    `proof-${req.user.id}-${commitmentId}-${Date.now()}`,

                folder: "/commitment-proofs"
            });

            // Save today's proof temporarily
            // Completion will create the DailyProgress record.
            commitment.todayProofUrl = result.url;
            commitment.todayProofFileId = result.fileId;

            await commitment.save();

            res.status(201).json({

                message:
                    "Proof uploaded successfully. You can now mark today's commitment complete.",

                proofUrl: result.url,

                proofFileId: result.fileId

            });

        } catch (error) {

            console.error(
                "Proof upload error:",
                error
            );

            res.status(500).json({
                message:
                    "Failed to upload proof image."
            });
        }
    }
);


// =========================
// AI VERIFY PROOF
// =========================

router.post(
    "/verify",

    async (req, res) => {

        try {

            const {
                commitmentId,
                proofUrl,
                proofFileId
            } = req.body;


            if (!commitmentId) {

                return res.status(400).json({

                    message:
                        "Commitment ID is required."

                });

            }


            if (!proofUrl) {

                return res.status(400).json({

                    message:
                        "Proof image URL is required."

                });

            }


            // =========================
            // GET COMMITMENT
            // =========================

            const commitment =
                await Commitment.findOne({

                    _id: commitmentId,

                    userId: req.user.id

                });


            if (!commitment) {

                return res.status(404).json({

                    message:
                        "Commitment not found."

                });

            }


            // =========================
            // TODAY
            // =========================

            const today =
                startOfDay()
                    .toISOString()
                    .slice(0, 10);


            // =========================
            // GET TODAY'S CHALLENGE
            // =========================

            const challenge =
                await DailyChallenge.findOne({

                    commitmentId:
                        commitment._id,

                    userId:
                        req.user.id,

                    date: today

                });


            if (!challenge) {

                return res.status(400).json({

                    message:
                        "Today's AI challenge has not been created."

                });

            }


            // =========================
            // CHECK WHETHER ALREADY DONE
            // =========================

            const existingProgress =
                await DailyProgress.findOne({

                    commitmentId:
                        commitment._id,

                    userId:
                        req.user.id,

                    date: today

                });


            if (existingProgress) {

                return res.status(409).json({

                    message:
                        "Today's commitment has already been recorded."

                });

            }


            // =========================
            // AI VERIFICATION
            // =========================

            const result =
                await verifyProof({

                    imageUrl:
                        proofUrl,

                    challenge:
                        challenge.challenge,

                    commitment: {

                        name:
                            commitment.name,

                        description:
                            commitment.description,

                        category:
                            commitment.category

                    }

                });


            const verified =
                Boolean(result.verified);


            // =========================
            // IF NOT VERIFIED
            // =========================

            if (!verified) {

                return res.json({

                    message:
                        "Proof was not accepted.",

                    verified: false,

                    confidence:
                        result.confidence,

                    reason:
                        result.reason,

                    challenge:
                        challenge.challenge

                });

            }


            // =========================
            // VERIFIED
            // =========================

            commitment.currentStreak += 1;


            commitment.longestStreak =
                Math.max(

                    commitment.longestStreak,

                    commitment.currentStreak

                );


            commitment.daysCompleted += 1;


            // =========================
            // CHECK COMPLETION
            // =========================

            if (
                commitment.daysCompleted >=
                commitment.durationDays
            ) {

                commitment.status =
                    "completed";

            }


            await commitment.save();


            // =========================
            // CREATE DAILY PROGRESS
            // =========================

            const progress =
                await DailyProgress.create({

                    userId:
                        req.user.id,

                    commitmentId:
                        commitment._id,

                    date:
                        today,

                    status:
                        "completed",

                    completed:
                        true,

                    commitmentAmount:
                        commitment.currentCommitment,

                    streak:
                        commitment.currentStreak,

                    completedAt:
                        new Date(),

                    proofUrl:
                        proofUrl,

                    proofFileId:
                        proofFileId || null,

                    aiChallenge:
                        challenge.challenge,

                    aiVerified:
                        true,

                    aiVerificationMessage:
                        `${result.confidence}% confidence — ${result.reason}`

                });


            // =========================
            // RESPONSE
            // =========================

            res.json({

                message:
                    "Proof verified successfully. Today's commitment is complete!",

                verified: true,

                confidence:
                    result.confidence,

                reason:
                    result.reason,

                challenge:
                    challenge.challenge,

                commitment,

                progress

            });

        } catch (error) {

            console.error(
                "AI verification error:",
                error
            );

            res.status(500).json({

                message:
                    "Failed to verify proof."

            });

        }

    }
);


module.exports = router;