const express = require("express");

const Commitment = require("../models/Commitment");
const DailyProgress = require("../models/DailyProgress");
const authMiddleware = require("../middleware/authMiddleware");
const { generateDailyChallenge } = require("../utils/challengeGenerator");

const router = express.Router();

router.use(authMiddleware);


// ======================================================
// HELPER FUNCTIONS
// ======================================================

function startOfDay(date = new Date()) {
    const value = new Date(date);

    value.setHours(0, 0, 0, 0);

    return value;
}


function getDateKey(date = new Date()) {
    return startOfDay(date)
        .toISOString()
        .slice(0, 10);
}


function dateDifference(date1, date2) {
    const first = startOfDay(new Date(date1));
    const second = startOfDay(new Date(date2));

    return Math.round(
        (first - second) / 86400000
    );
}


// Calculate current and longest streak from actual records
function calculateStreaks(records) {

    if (!records || records.length === 0) {
        return {
            currentStreak: 0,
            longestStreak: 0
        };
    }


    const sortedRecords = [...records].sort(
        (a, b) =>
            new Date(`${a.date}T00:00:00`) -
            new Date(`${b.date}T00:00:00`)
    );


    let runningStreak = 0;
    let longestStreak = 0;

    let previousDate = null;


    for (const record of sortedRecords) {

        if (record.status !== "completed") {

            runningStreak = 0;
            previousDate = record.date;

            continue;
        }


        if (!previousDate) {

            runningStreak = 1;

        } else {

            const gap =
                dateDifference(
                    new Date(`${record.date}T00:00:00`),
                    new Date(`${previousDate}T00:00:00`)
                );


            if (gap === 1) {

                runningStreak += 1;

            } else {

                // Any gap breaks the streak
                runningStreak = 1;
            }
        }


        longestStreak =
            Math.max(
                longestStreak,
                runningStreak
            );


        previousDate = record.date;
    }


    // Current streak must actually reach today
    const today = getDateKey();

    const lastRecord =
        sortedRecords[sortedRecords.length - 1];


    if (
        lastRecord.status !== "completed" ||
        dateDifference(
            new Date(`${today}T00:00:00`),
            new Date(`${lastRecord.date}T00:00:00`)
        ) !== 0
    ) {

        // If the latest completed record is not today,
        // the active streak is no longer current.
        return {
            currentStreak: 0,
            longestStreak
        };
    }


    return {
        currentStreak: runningStreak,
        longestStreak
    };
}


// ======================================================
// GET ALL COMMITMENTS
// ======================================================

router.get("/", async (req, res) => {

    try {

        const commitments =
            await Commitment.find({
                userId: req.user.id
            }).sort({
                createdAt: -1
            });


        res.json({
            commitments
        });

    } catch (error) {

        console.error(
            "Get commitments error:",
            error
        );

        res.status(500).json({
            message:
                "Failed to fetch commitments."
        });
    }
});


// ======================================================
// CREATE COMMITMENT
// ======================================================

router.post("/", async (req, res) => {

    try {

        const {
            name,
            description,
            category,
            frequency = "daily",
            durationDays = 30,
            startingCommitment = 100,
            escalationMultiplier = 2,
            maximumCommitment = 800,
            deadline = "21:00"
        } = req.body;


        if (
            !name ||
            !description ||
            !category
        ) {

            return res.status(400).json({
                message:
                    "Name, description and category are required."
            });
        }


        const startDate =
            startOfDay();


        const duration =
            Math.max(
                1,
                Number(durationDays) || 30
            );


        const starting =
            Math.max(
                1,
                Number(startingCommitment) || 100
            );


        const multiplier =
            Number(escalationMultiplier) || 2;


        const maximum =
            Math.max(
                starting,
                Number(maximumCommitment) || 800
            );


        const endDate =
            new Date(
                startDate.getTime() +
                (duration - 1) * 86400000
            );


        const commitment =
            await Commitment.create({

                userId:
                    req.user.id,

                name:
                    String(name).trim(),

                description:
                    String(description).trim(),

                category:
                    String(category).trim(),

                frequency,

                durationDays:
                    duration,

                startingCommitment:
                    starting,

                currentCommitment:
                    starting,

                escalationMultiplier:
                    multiplier,

                maximumCommitment:
                    maximum,

                deadline,

                startDate,

                endDate,

                currentStreak:
                    0,

                longestStreak:
                    0,

                daysCompleted:
                    0,

                status:
                    "active"
            });


        res.status(201).json({

            message:
                "Commitment created successfully.",

            commitment
        });

    } catch (error) {

        console.error(
            "Create commitment error:",
            error
        );

        res.status(500).json({
            message:
                "Failed to create commitment."
        });
    }
});


// ======================================================
// GET SINGLE COMMITMENT
// ======================================================

router.get("/:id", async (req, res) => {

    try {

        const commitment =
            await Commitment.findOne({

                _id:
                    req.params.id,

                userId:
                    req.user.id
            });


        if (!commitment) {

            return res.status(404).json({
                message:
                    "Commitment not found."
            });
        }


        const progress =
            await DailyProgress.find({

                commitmentId:
                    commitment._id,

                userId:
                    req.user.id

            }).sort({
                date: 1
            });


        res.json({

            commitment,

            progress
        });

    } catch (error) {

        console.error(
            "Get commitment error:",
            error
        );

        res.status(500).json({
            message:
                "Failed to fetch commitment."
        });
    }
});


// ======================================================
// GET TODAY'S AI CHALLENGE
// ======================================================

router.get(
    "/:id/today-challenge",
    async (req, res) => {

        try {

            const commitment =
                await Commitment.findOne({

                    _id:
                        req.params.id,

                    userId:
                        req.user.id
                });


            if (!commitment) {

                return res.status(404).json({
                    message:
                        "Commitment not found."
                });
            }


            const today =
                getDateKey();


            // If today's progress already exists,
            // return the challenge stored with it.
            const todayProgress =
                await DailyProgress.findOne({

                    commitmentId:
                        commitment._id,

                    userId:
                        req.user.id,

                    date:
                        today
                });


            if (
                todayProgress &&
                todayProgress.aiChallenge
            ) {

                return res.json({

                    challenge:
                        todayProgress.aiChallenge
                });
            }


            // Generate personalized challenge
            const challenge =
                await generateDailyChallenge({

                    name:
                        commitment.name,

                    description:
                        commitment.description,

                    category:
                        commitment.category
                });


            res.json({

                challenge:
                    challenge ||
                    `Complete today's "${commitment.name}" task as planned.`
            });

        } catch (error) {

            console.error(
                "Daily challenge error:",
                error
            );


            // Safe fallback if challenge generation fails
            res.json({

                challenge:
                    "Complete today's commitment according to your planned task and keep genuine proof of your work."
            });
        }
    }
);


// ======================================================
// MARK TODAY'S PROGRESS
// ======================================================

router.post(
    "/:id/progress",
    async (req, res) => {

        try {

            const {
                status = "completed"
            } = req.body;


            if (
                !["completed", "missed"]
                    .includes(status)
            ) {

                return res.status(400).json({

                    message:
                        "Status must be completed or missed."
                });
            }


            const commitment =
                await Commitment.findOne({

                    _id:
                        req.params.id,

                    userId:
                        req.user.id
                });


            if (!commitment) {

                return res.status(404).json({

                    message:
                        "Commitment not found."
                });
            }


            const today =
                getDateKey();


            // ==================================================
            // CHECK WHETHER TODAY IS ALREADY RECORDED
            // ==================================================

            const existingRecord =
                await DailyProgress.findOne({

                    commitmentId:
                        commitment._id,

                    userId:
                        req.user.id,

                    date:
                        today
                });


            if (existingRecord) {

                return res.status(409).json({

                    message:
                        "Today's commitment has already been recorded."
                });
            }


            // ==================================================
            // COMPLETED
            // ==================================================

            if (status === "completed") {

                // ----------------------------------------------
                // PROOF IS REQUIRED
                // ----------------------------------------------

                if (!commitment.todayProofUrl) {

                    return res.status(400).json({

                        message:
                            "Please upload today's proof image before marking the commitment complete."
                    });
                }


                // ----------------------------------------------
                // GET PREVIOUS PROGRESS
                // ----------------------------------------------

                const previousProgress =
                    await DailyProgress.find({

                        commitmentId:
                            commitment._id,

                        userId:
                            req.user.id

                    }).sort({
                        date: -1
                    });


                const lastRecord =
                    previousProgress[0];


                // ----------------------------------------------
                // STREAK LOGIC
                // ----------------------------------------------

                if (!lastRecord) {

                    // First completed day
                    commitment.currentStreak = 1;

                } else {

                    const gap =
                        dateDifference(
                            new Date(`${today}T00:00:00`),
                            new Date(`${lastRecord.date}T00:00:00`)
                        );


                    if (
                        lastRecord.status === "completed" &&
                        gap === 1
                    ) {

                        // Yesterday was completed
                        // Continue streak
                        commitment.currentStreak += 1;

                    } else {

                        // Any missed day OR any gap
                        // starts a NEW streak
                        commitment.currentStreak = 1;
                    }
                }


                commitment.longestStreak =
                    Math.max(
                        Number(
                            commitment.longestStreak
                        ) || 0,

                        commitment.currentStreak
                    );


                commitment.daysCompleted =
                    Number(
                        commitment.daysCompleted
                    ) + 1;
            }


            // ==================================================
            // MISSED
            // ==================================================

            else {

                // Missed day always breaks streak
                commitment.currentStreak = 0;


                // Escalate commitment amount
                commitment.currentCommitment =
                    Math.min(

                        commitment.maximumCommitment,

                        Math.round(

                            commitment.currentCommitment *
                            commitment.escalationMultiplier

                        )
                    );
            }


            // ==================================================
            // CHECK COMMITMENT COMPLETION
            // ==================================================

            if (
                commitment.daysCompleted >=
                commitment.durationDays
            ) {

                commitment.status =
                    "completed";
            }


            await commitment.save();


            // ==================================================
            // GET TODAY'S AI CHALLENGE
            // ==================================================

            let todayChallenge = "";


            try {

                todayChallenge =
                    await generateDailyChallenge({

                        name:
                            commitment.name,

                        description:
                            commitment.description,

                        category:
                            commitment.category
                    });

            } catch (challengeError) {

                console.error(
                    "Challenge generation failed:",
                    challengeError
                );

                todayChallenge =
                    `Complete today's "${commitment.name}" task as planned.`;
            }


            // ==================================================
            // CREATE DAILY PROGRESS RECORD
            // ==================================================

            const progress =
                await DailyProgress.create({

                    userId:
                        req.user.id,

                    commitmentId:
                        commitment._id,

                    date:
                        today,

                    status,

                    completed:
                        status === "completed",

                    commitmentAmount:
                        commitment.currentCommitment,

                    streak:
                        commitment.currentStreak,

                    completedAt:
                        status === "completed"
                            ? new Date()
                            : null,

                    proofUrl:
                        commitment.todayProofUrl || null,

                    proofFileId:
                        commitment.todayProofFileId || null,

                    aiChallenge:
                        todayChallenge || null
                });


            // ==================================================
            // CLEAR TEMPORARY PROOF
            // ==================================================

            commitment.todayProofUrl =
                null;

            commitment.todayProofFileId =
                null;


            await commitment.save();


            res.status(201).json({

                message:
                    `Today's commitment marked ${status}.`,

                commitment,

                progress
            });

        } catch (error) {

            // Duplicate progress record
            if (
                error.code === 11000
            ) {

                return res.status(409).json({

                    message:
                        "Today's commitment has already been recorded."
                });
            }


            console.error(
                "Progress update error:",
                error
            );


            res.status(500).json({

                message:
                    "Failed to update today's progress."
            });
        }
    }
);


// ======================================================
// RESET TODAY
// ======================================================

router.post(
    "/:id/reset-today",
    async (req, res) => {

        try {

            const commitment =
                await Commitment.findOne({

                    _id:
                        req.params.id,

                    userId:
                        req.user.id
                });


            if (!commitment) {

                return res.status(404).json({

                    message:
                        "Commitment not found."
                });
            }


            const today =
                getDateKey();


            const record =
                await DailyProgress.findOneAndDelete({

                    commitmentId:
                        commitment._id,

                    userId:
                        req.user.id,

                    date:
                        today
                });


            if (!record) {

                return res.status(404).json({

                    message:
                        "No progress record exists for today."
                });
            }


            // Get all remaining records
            const records =
                await DailyProgress.find({

                    commitmentId:
                        commitment._id,

                    userId:
                        req.user.id

                }).sort({
                    date: 1
                });


            // Recalculate streaks from actual dates
            const streakData =
                calculateStreaks(records);


            commitment.currentStreak =
                streakData.currentStreak;


            commitment.longestStreak =
                streakData.longestStreak;


            commitment.daysCompleted =
                records.filter(
                    item =>
                        item.status === "completed"
                ).length;


            if (
                commitment.daysCompleted <
                commitment.durationDays
            ) {

                commitment.status =
                    "active";
            }


            await commitment.save();


            res.json({

                message:
                    "Today's progress has been reset.",

                commitment
            });

        } catch (error) {

            console.error(
                "Reset progress error:",
                error
            );


            res.status(500).json({

                message:
                    "Failed to update today's progress."
            });
        }
    }
);


module.exports = router;